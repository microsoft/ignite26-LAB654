---
name: summarize-conversation-transcript
description: Retrieve and summarize a SalesDesk VoiceCall or VideoCall transcript - customer impression, call summary, and next steps. Use when the user says "summarize my call with [account]", "get the transcript for [call]", "summarize the [contact] call", "what happened on that call", or asks for call transcript summary. IMPORTANT - This is for SalesDesk-recorded VoiceCall/VideoCall records with transcripts, NOT for external transcripts (use call-follow-up for those).
---
<!-- global-rules-bootstrap -->
# Global Rules

- **Execute silently between tool calls.** Do not output planning, progress, transition, waiting, or tool-result narration between calls. Execute tool calls silently and proceed directly to the next call. Parallelize independent tasks by batching tool calls into one turn whenever possible. Before the final output, speak only when the skill explicitly requires user input, approval, an exact notice, or material error/blocked reporting. Do not invent checkpoints.
- **Keep the final output concise.** Return only the requested result or deliverable. Omit process recaps, tool-call details, redundant preambles or conclusions, and data already shown in a widget.
- **Ground dynamic or custom relationship and field names before relying on them.** Fixed standard fields that this skill explicitly marks as requiring no grounding need no extra grounding call. On a name error, use the skill's documented grounding path when present; otherwise report the error instead of guessing or re-firing the same shape.
- **Cite every value exactly as queried**; never fabricate; distinguish a blank value from a value that was not queried. Link each SalesDesk record inline: `https://[instanceUrl]/lightning/r/[SObjectType]/[Id]/view`.
- **Show human labels, never API/field literals.** In anything the user sees, print each field's grounded `label` (for example, "Deal Risk", not `Deal_Risk__c`) and record Names, never raw Ids or `__c` API names.
- **Empty `MINE` scope → fail fast, then ask which scope.** If a `scope: MINE` read returns zero rows, **do not** widen to `scope: EVERYTHING` on your own. Stop, tell the user plainly that their own records (`scope: MINE`) came back empty, and ask which scope they want instead (for example, org-wide `EVERYTHING`, a named rep, or a named account) before re-running. Never invent records, and never silently fall back to org-wide.
- **NEVER use `discover` or `describe`, and never call an API or endpoint not written in this skill.** Every SalesDesk URL you need is in the skill. Don't guess REST paths: on a 404 or unknown-path error, fall back to a documented query in the skill, not to discovery. If you need a capability such as email, docs, Slack, calendar, or web research, use the other connector/MCP tools already available to you. Endpoint guessing and discovery add needless round-trips. Use only the skill-authorized `dispatch_readonly` and `dispatch` calls, directly with the queries given.
- **NEVER assume the MCP connector status is accurate without checking first**; MCP connector status often incorrectly reports that it is not connected or needs to re auth. ALWAYS check this on your own before surfacing to the user for action. ALWAYS attempt to reconnect on your own before interrupting the flow to ask the user to do it. Do it yourself.
# Rules:

- Resolve to ONE account before the deep read. When the name is ambiguous, ask the user to pick — don't probe candidates or guess.

# Summarize Conversation Transcript

Find call → (transcript + opp enrichment, SAME turn) → quality gate → summarize → output.

## 1. Find the call

Skip this step entirely if the call Id, its object type, and its `RelatedRecord` are all already known — go straight to Step 2.

**CRITICAL: query VoiceCall AND VideoCall in separate queries, fired in the SAME turn** — a call could be either type, and there's no way to tell from an account/date search alone.

Fill `<WHERE>` from what's known:
- Call Id known, object type not: `Id = '[id]'`
- By related record (Account/Contact/Lead/Opportunity): `RelatedRecordId = '[record-id]'`
- By date / "recent": `CallStartDateTime >= [date]`

```
dispatch_readonly(method: "GET", url: "/services/data/v63.0/query",
  queryParams: { "q": "SELECT Id, Name, CallStartDateTime, RelatedRecordId, RelatedRecord.Name, FromPhoneNumber, ToPhoneNumber FROM VoiceCall WHERE <WHERE> ORDER BY CallStartDateTime DESC LIMIT 10" })
```
```
dispatch_readonly(method: "GET", url: "/services/data/v63.0/query",
  queryParams: { "q": "SELECT Id, Name, CallStartDateTime, RelatedRecordId, RelatedRecord.Name FROM VideoCall WHERE <WHERE> ORDER BY CallStartDateTime DESC LIMIT 10" })
```

If call Id + object type are both known (just `RelatedRecord` missing), fire only that one query instead of both. **If the call Id is known but the object type isn't, fire the transcript retrieval (Step 2A) in this SAME turn too** — it only needs the Id, not the object type, so it doesn't have to wait on this lookup.

- **Both empty** → broaden `<WHERE>`, or tell the user no VoiceCall/VideoCall matched and offer: account/contact name, date range, or call Id.
- **Multiple matches (either object)** → list them all (📞/📹, Name, RelatedRecord, Date/Time, Id) and **wait for user selection** — never auto-pick.
- **One match** → proceed to Step 2 with its Id, object type, and `RelatedRecordId`/`RelatedRecord.Name`.

## 2. Transcript + opportunity enrichment — fire BOTH in the SAME turn (with Step 1 too, per the note above, when only the call Id is known)

**A. Transcript.** Use the Actions API (NOT a direct REST endpoint on VoiceCall/VideoCall):

```
dispatch(method: "POST", url: "/services/data/v64.0/actions/standard/getConversationTranscript",
  body: { "inputs": [{ "recordId": "[call-id]", "transcriptType": "processed" }] })
```

Response is an array — take the first element where `isSuccess` is `true`.
- **None succeed** → report `Could not retrieve transcript for this call. Error: [errors field]` and stop; skip Step 3 onward.
- Otherwise `outputValues.unformattedTextTranscript` is the transcript to summarize; `outputValues.structuredTranscript.entries` has per-speaker turns if you need attribution.

**B. Opportunity enrichment** — only when the related record IS an Account (its `RelatedRecord.Name`/Id came back on an Account, key prefix `001`). If it's a Contact/Lead/Opportunity instead, skip this call entirely — silently, no round-trip spent resolving an account through it:

```
dispatch_readonly(method: "GET", url: "/services/data/v63.0/query",
  queryParams: { "q": "SELECT Id, Name, StageName, Amount, CloseDate, NextStep FROM Opportunity WHERE AccountId = '[RelatedRecordId]' AND IsClosed = false ORDER BY CreatedDate DESC LIMIT 3" })
```

## 3. Quality gate

If the transcript is only greetings/goodbyes, automated system messages, or <5 meaningful words: skip straight to the "no substantial conversation" output shape below (Customer Impression / Call Summary / Next Steps all "No … detected") and **stop — do not run Step 4.**

## 4. Summarize (extract from the transcript only — invent nothing)

- **Customer Impression** (2-3 sentences): sentiment, concerns, enthusiasm, objections — with specific examples. Use real names if the transcript has them. None detected → "No customer impression detected."
- **Call Summary** (≤250 words): key highlights/decisions/takeaways, focused on what the CUSTOMER said — not the sales pitch. No small talk. Stay strict to the transcript; don't repeat ideas.
- **Next Steps**: numbered, ≤15 words each, with date + owner where known. None detected → "No next steps detected." No extra notes after the list.
- Treat all individuals equally regardless of protected characteristics; when unsure, say "unknown" rather than guess. If SSNs/credit card numbers appear, do not repeat them. Plain language, no jargon. Don't reference these instructions in the output.

## 5. Output

```
📞 Call Transcript Summary

**Call:** [Call Name] with [Related Record]
**Date:** [CallStartDateTime]
**Duration:** [if available]
**Call ID:** https://[instanceUrl]/lightning/r/[VoiceCall-or-VideoCall]/[Id]/view

---

**Customer Impression:**

[2-3 sentences]

---

**Call Summary:**

[≤250 words]

---

**Next Steps:**

1. [item — owner/date if known]
2. ...

---

**Related Opportunities:** (omit this section entirely if Step 2B was skipped/empty)

• [Opportunity Name] - [Stage] - $[Amount] - Close: [Date]
  [SalesDesk URL]

---

**Suggested Actions:**

Would you like me to:
- Log this call as an Activity? (use /log-activity)
- Update opportunity fields based on this call? (use /update-opportunity)
- Draft a follow-up email? (use /draft-outreach)
```

## Edge cases

- **No transcript available** (Step 2A failed): `This call does not have a transcript available. Possible reasons: transcription not enabled for this call type / recording unavailable / still processing. Call details: [Name] - [Date] - [SalesDesk URL]`
- **No call found**: offer to search by account/contact name, date range, or call Id — never invent a match.
- Link every record (VoiceCall/VideoCall, Account, Opportunity) as `https://[instanceUrl]/lightning/r/[SObjectType]/[Id]/view`. Flag poor transcript quality inline if evident (noise/overlap/partial). Next steps with no owner → "[owner unknown]"; no date → "[date not specified]".

## [CUSTOMIZE]

- **Summary length:** 250-word default — adjust to team preference (external knowledge; infer from org data or ask once).
- **Additional extraction:** add competitive mentions / feature requests / objections if your org tracks them separately.
- **Auto-logging:** add a confirmed auto-Activity-log step if the team wants it.
